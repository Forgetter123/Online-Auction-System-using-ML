from flask import Blueprint, request, render_template, redirect, flash
import pickle
import numpy as np

ml_routes = Blueprint('ml_routes', __name__)

# Load ML models
with open('ml_model.pkl', 'rb') as f:
    price_model = pickle.load(f)

with open('fraud_model.pkl', 'rb') as f:
    fraud_model = pickle.load(f)

@ml_routes.route('/predict_price', methods=['POST'])
def predict_price():
    try:
        starting_bid = float(request.form['starting_bid'])
        duration = int(request.form['duration'])
        category_id = int(request.form['category_id'])

        features = np.array([[starting_bid, duration, category_id]])
        prediction = price_model.predict(features)[0]

        return render_template('auction_detail.html', prediction=round(prediction, 2))

    except Exception as e:
        flash(f"Price prediction failed: {e}", "danger")
        return redirect('/auction_list')


@ml_routes.route('/check_fraud', methods=['POST'])
def check_fraud():
    try:
        bid_amount = float(request.form['bid_amount'])
        user_rating = float(request.form['user_rating'])
        num_previous_bids = int(request.form['num_previous_bids'])

        features = np.array([[bid_amount, user_rating, num_previous_bids]])
        result = fraud_model.predict(features)[0]

        if result == 1:
            flash("⚠️ Fraudulent behavior detected! Your action has been logged.", "danger")
        else:
            flash("✅ No fraud detected. You may proceed safely.", "success")

    except Exception as e:
        flash(f"Fraud check failed: {e}", "danger")

    return redirect('/payment')